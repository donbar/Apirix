<!DOCTYPE html>
<html>
<head>
    <title>Kendo UI DataViz Examples</title>
    <link href="../content/shared/styles/suite.css" rel="stylesheet">
</head>
<body>
    <div id="page">
        <a class="offline-button" href="../index.php">Back to all suites</a>
<?php
    $jsonFilename = '../content/dataviz.nav.json';

    require_once '../include/navigation.php';
?>
    </div>
</body>
</html>
