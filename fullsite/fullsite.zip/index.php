<html>
<head>
<style>
	html{
	    /* This image will be displayed fullscreen */
	    background:url('images/building.jpg') no-repeat center center;
	
	    /* Ensure the html element always takes up the full height 		of the browser window */
	    min-height:100%;
	
	    /* The Magic */
	    background-size:cover;
	}


	body{
	    /* Workaround for some mobile browsers */
	    min-height:100%;
	}
	p{
	     font-family:"arial";
	     font-style:normal;
	     font-size: 32px;
	     color:#FFFFFF;
	}
	.redlogofont{
	     font-family:"arial";
	     font-style:normal;
	     font-size: 32px;
	     color:#FF0000;
	     text-shadow: 1px 1px #000000;
	}
	.smalllogofont{
	     font-family:"arial";
	     font-style:normal;
	     font-size: 22px;
	     color:#FF0000;
	     text-shadow: 1px 1px #000000;
	}
	.box {
	    text-align: left;
	    background-color:#F5F1F1;
	    color:#000000;
	    font-weight:bold;
	    height:150px;
	    width: 400px;
	    position: absolute;
	    left: 50%;
	    top: 50%; 
	    margin-left: -200px;
	    margin-top: -75px;
	}

</style>
</head>
<body>
<p class="redlogofont">
Apirix<br>
<font class="smalllogofont">
Introducing jobseekers and employers through advanced analytics
</font>
</p>
<div class='box'>
<br>
This site is not yet available.  Please check back again.
</div>
</body>
</html>